<template>
  <div>
    <ul>
      <li>
        <a><router-link to="/">Home</router-link></a>
      </li>
      <li>
        <a><router-link to="/register">Register</router-link></a>
      </li>
      <li>
        <a><router-link to="/login">Login</router-link></a>
      </li>
      <li>
        <a><router-link to="/about">About</router-link></a>
      </li>
    </ul>

    <div><router-view /></div>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld";

export default {
  name: "App",
  components: {
    HelloWorld
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  width: 100%;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 100%;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #111;
}
</style>
