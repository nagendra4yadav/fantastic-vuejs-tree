<template>
  <div>
    <v-layout align-center justify-center row fill-height>
      <table>
        <tr>
          <th>Name</th>
          <th>Age</th>
          <th>Movie</th>
          <th>Action</th>
        </tr>
        <tr class="tablecss" v-for="udata in userData" v-bind:key="udata.name">
          <td>{{ udata.name }}</td>
          <td>{{ udata.age }}</td>
          <td>{{ udata.movie }}</td>
          <td>
            <button @click="updateUser(udata);">Update</button>&nbsp;<button
              @click="removeInfo"
            >
              Remove
            </button>
          </td>
        </tr>
      </table>
    </v-layout>
  </div>
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "userInfoList",
  computed: mapState({
    // arrow functions can make the code very succinct!
    userData: state => state.userListInfo
  }),

  methods: {
    updateUser(selectedInfo) {
      this.$store.commit("loadUser", selectedInfo);
    },
    removeInfo(selectedInfo) {
      this.$store.commit("removeUser", selectedInfo);
    }
  }
};
</script>
<style>
.tablecss {
  color: red;
}
</style>
