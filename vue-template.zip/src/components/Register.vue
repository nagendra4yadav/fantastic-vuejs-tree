<template>
  <div>
    <form id="app">
      <!--
        <p v-if="errors.length">
          <b>Please correct the following error(s):</b>
          <ul>
            <li v-for="error in errors">{{ error }}</li>
          </ul>
        </p> !
      -->
      <br />
      <div style="background-color:yellowgreen;padding:10px;">
        Register User
      </div>

      <table>
        <tr>
          <td>Name</td>
          <td>:</td>
          <td>
            <input id="name" v-model="userInfo.name" type="text" name="name" />
          </td>
        </tr>
        <tr>
          <td>Age</td>
          <td>:</td>
          <td>
            <input
              id="age"
              v-model="userInfo.age"
              type="number"
              name="age"
              min="0"
            />
          </td>
        </tr>
        <tr>
          <td>Favorite Movie</td>
          <td>:</td>
          <td>
            <select id="movie" v-model="userInfo.movie" name="movie">
              <option>Star Wars</option>
              <option>Vanilla Sky</option>
              <option>Atomic Blonde</option>
            </select>
          </td>
        </tr>

        <tr>
          <td></td>
          <td></td>
          <td>
            <input type="button" @click="checkForm" value="Submit" />
            &nbsp;<button @click="reSet(this);">cancel</button>
          </td>
        </tr>
      </table>
    </form>
    <hr />
    <userInfoList />
  </div>
</template>
<script>
import writejsonfile from "write-json-file";
import userInfoList from "./userInfoList.vue";
import { mapState } from "vuex";
export default {
  name: "userInfo",
  components: {
    userInfoList
  },
  data() {
    return {
      errors: []
    };
  },
  computed: mapState({
    // arrow functions can make the code very succinct!
    userInfo: state => state.userInfo
  }),
  methods: {
    checkForm: function(e) {
      debugger;
      if (this.userInfo.name && this.userInfo.age) {
        this.$store.commit("addUser", this.userInfo);
      }
      this.errors = [];
      if (!this.userInfo.name) {
        this.errors.push("Name required.");
      }
      if (!this.userInfo.age) {
        this.errors.push("Age required.");
      }
      e.preventDefault();
    },
    reSet(e) {
      this.userInfo = {};
      e.preventDefault();
    },

    saveInfo() {
      debugger;
      (async () => {
        await writejsonfile("../jsonFile/UserInfo.json", {
          name: this.userInfo.name,
          age: this.userInfo.age,
          movie: this.userInfo.movie
        });
      })();
    }
  }
};
</script>
