import Vue from "vue";
import App from "./App.vue";
import routes from "./Routes";
import VueRouter from "vue-router";
import store from "./Store/TodoStore";

Vue.use(VueRouter);
Vue.config.productionTip = false;
const router = new VueRouter({ routes });
new Vue({
  store,
  router,
  render: h => h(App)
}).$mount("#app");
