import Vue from "vue";
import Vuex from "vuex";
import data from "../jsonFile/UserInfo.json";
import fss from "fs";
Vue.use(Vuex);
export default new Vuex.Store({
  state: {
    toDos: [],
    userListInfo: data.userInfo,
    userInfo: {
      name: null,
      age: null,
      movie: null
    }
  },
  mutations: {
    addToDo(state, payload) {
      state.toDos.push(payload);
      localStorage.setItem("toDoList", state.toDos);
      console.log(state.toDos);
    },
    loadData(state) {
      state.toDos = localStorage.getItem("toDoList");
    },
    removeItem(state, name) {
      var index = state.toDos.indexOf(name);
      state.toDos.splice(index, 1);
    },
    addUser(state, payload) {
      debugger;
      state.userListInfo.push(payload);
      let data = JSON.stringify(payload);
      fss.writeFileSync("src/jsonFile/UserInfo.json", data);
    },
    loadUser(state, payload) {
      debugger;
      state.userInfo = {
        name: payload.name,
        age: payload.age,
        movie: payload.movie
      };
    },
    removeUser(state, payload) {
      var index = state.userListInfo.indexOf(payload);
      state.userListInfo.splice(index, 1);
    }
  }
});
